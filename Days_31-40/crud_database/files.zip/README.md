# Todo CRUD App — MongoDB + Mongoose + Express

## Project Structure

```
todo-app/
├── server.js          ← Entry point, connects to MongoDB, starts Express
├── models/
│   └── Todo.js        ← Mongoose schema & model
├── routes/
│   └── todos.js       ← All CRUD route handlers
├── .env.example       ← Copy to .env and set your values
└── package.json
```

## Setup

### 1. Install MongoDB
- **macOS:** `brew install mongodb-community && brew services start mongodb-community`
- **Windows:** Download from https://www.mongodb.com/try/download/community
- **Or use MongoDB Atlas (cloud):** https://www.mongodb.com/atlas — free tier available

### 2. Install dependencies
```bash
npm install
```

### 3. Configure environment
```bash
cp .env.example .env
# Edit .env if needed (defaults work for local MongoDB)
```

### 4. Run the server
```bash
npm run dev      # with auto-reload (nodemon)
# or
npm start        # without auto-reload
```

---

## API Reference

| Method | Endpoint          | Description        |
|--------|-------------------|--------------------|
| POST   | /api/todos        | Create a todo      |
| GET    | /api/todos        | Get all todos      |
| GET    | /api/todos/:id    | Get one todo       |
| PUT    | /api/todos/:id    | Update a todo      |
| DELETE | /api/todos/:id    | Delete a todo      |

---

## Example Requests (using curl)

### Create
```bash
curl -X POST http://localhost:3000/api/todos \
  -H "Content-Type: application/json" \
  -d '{"title": "Buy milk"}'
```

### Get All
```bash
curl http://localhost:3000/api/todos
```

### Get One
```bash
curl http://localhost:3000/api/todos/<id>
```

### Update
```bash
curl -X PUT http://localhost:3000/api/todos/<id> \
  -H "Content-Type: application/json" \
  -d '{"title": "Buy oat milk", "completed": true}'
```

### Delete
```bash
curl -X DELETE http://localhost:3000/api/todos/<id>
```

---

## Key Concepts

- **Mongoose Schema** — defines the shape & rules for your data (`models/Todo.js`)
- **Model** — `Todo.create()`, `Todo.find()`, `Todo.findById()`, etc. are the database operations
- **`timestamps: true`** — Mongoose auto-manages `createdAt` / `updatedAt` for you
- **`findByIdAndUpdate(..., { new: true })`** — returns the updated document (not the old one)
