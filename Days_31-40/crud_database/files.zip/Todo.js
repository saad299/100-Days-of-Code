const mongoose = require("mongoose");

// Define the shape of a Todo document in MongoDB
const todoSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: [true, "Title is required"],
      trim: true,
    },
    completed: {
      type: Boolean,
      default: false,
    },
  },
  {
    timestamps: true, // Automatically adds createdAt and updatedAt fields
  }
);

// Export the model — Mongoose will create a "todos" collection in MongoDB
module.exports = mongoose.model("Todo", todoSchema);
