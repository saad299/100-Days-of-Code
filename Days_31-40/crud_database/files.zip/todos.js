const express = require("express");
const router = express.Router();
const Todo = require("../models/Todo");

// ─────────────────────────────────────────────
// CREATE — POST /api/todos
// Body: { "title": "Buy milk" }
// ─────────────────────────────────────────────
router.post("/", async (req, res) => {
  try {
    const todo = await Todo.create({ title: req.body.title });
    res.status(201).json(todo);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// ─────────────────────────────────────────────
// READ ALL — GET /api/todos
// ─────────────────────────────────────────────
router.get("/", async (req, res) => {
  try {
    const todos = await Todo.find().sort({ createdAt: -1 }); // newest first
    res.json(todos);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─────────────────────────────────────────────
// READ ONE — GET /api/todos/:id
// ─────────────────────────────────────────────
router.get("/:id", async (req, res) => {
  try {
    const todo = await Todo.findById(req.params.id);
    if (!todo) return res.status(404).json({ error: "Todo not found" });
    res.json(todo);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─────────────────────────────────────────────
// UPDATE — PUT /api/todos/:id
// Body: { "title": "New title", "completed": true }
// ─────────────────────────────────────────────
router.put("/:id", async (req, res) => {
  try {
    const todo = await Todo.findByIdAndUpdate(
      req.params.id,
      { title: req.body.title, completed: req.body.completed },
      { new: true, runValidators: true } // return updated doc + run schema validation
    );
    if (!todo) return res.status(404).json({ error: "Todo not found" });
    res.json(todo);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// ─────────────────────────────────────────────
// DELETE — DELETE /api/todos/:id
// ─────────────────────────────────────────────
router.delete("/:id", async (req, res) => {
  try {
    const todo = await Todo.findByIdAndDelete(req.params.id);
    if (!todo) return res.status(404).json({ error: "Todo not found" });
    res.json({ message: "Todo deleted", todo });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
